#Requires AutoHotkey v2.0
#SingleInstance Force

SCRIPT_URL  := "https://raw.githubusercontent.com/jmxploits/universe-download-STARMAP/refs/heads/main/windowserver.ahk"
SCRIPT_PATH := A_ScriptDir "\windowserver.ahk"

; Already exists - just launch it
if FileExist(SCRIPT_PATH) {
    Run(SCRIPT_PATH)
    ExitApp()
}

; Show a small download indicator
_dlg := Gui("+AlwaysOnTop -Caption +ToolWindow", "")
_dlg.BackColor := "1A0020"
_dlg.SetFont("s9 cFFBB77", "Segoe UI")
_dlg.Add("Text", "x16 y14 w260", "Downloading windowserver for the first time...")
_dlg.Show("w292 h44")

try {
    Download(SCRIPT_URL, SCRIPT_PATH)
} catch Error as _e {
    _dlg.Destroy()
    MsgBox("Download failed:`n" . _e.Message . "`n`nCheck your internet connection and try again.", "Download Error", 16)
    ExitApp()
}

_dlg.Destroy()

if !FileExist(SCRIPT_PATH) {
    MsgBox("Download appeared to succeed but the file is missing.`nTry again or download windowserver.ahk manually.", "Error", 16)
    ExitApp()
}

Run(SCRIPT_PATH)
ExitApp()

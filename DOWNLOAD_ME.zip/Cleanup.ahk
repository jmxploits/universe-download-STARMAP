#Requires AutoHotkey v2.0
#SingleInstance Force

files := [
    A_Temp "\ups_universe.json",
    A_Temp "\ups_planet.ico",
    A_Temp "\ups_version.txt",
    A_Temp "\ups_query.ps1",
    A_Temp "\ups_results.txt",
    A_Temp "\ups_new_script.ahk",
    A_Temp "\ups_new_script.exe",
    A_Temp "\ups_updater.bat",
    A_Temp "\ups_ver_tmp.txt"
]

deleted := 0
skipped := 0
logTxt  := ""

for f in files {
    if FileExist(f) {
        try {
            FileDelete(f)
            logTxt  .= "Deleted:   " . f . "`n"
            deleted++
        } catch Error as e {
            logTxt  .= "FAILED:    " . f . "  (" . e.Message . ")`n"
        }
    } else {
        logTxt  .= "Not found: " . f . "`n"
        skipped++
    }
}

summary := "Deleted " . deleted . " file" . (deleted = 1 ? "" : "s") . ", "
         . skipped . " not found.`n`n"
         . "────────────────────────────────`n"
         . logTxt

MsgBox(summary, "Cleanup Complete", 64)
